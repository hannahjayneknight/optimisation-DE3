Software/library prerequisites/dependencies needed to run the code = 
- The Optimization Toolbox by MATLAB
- Global Optimization Toolbox by MATLAB
- Statistics and machine learning toolbox by MATLAB 
- polyfitn function by John D’Errico.
 </br></br>

The main script = "optimisingmodel.m"; </br></br>

Provide an indication of the typical performance (e.g. execution time, with indication of processor and operating system) = Total time: 1.759 s, Windows 10 ;</br></br>